import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  hashPassword,
  verifyPassword,
  generateToken,
  toSafeUser,
  authMiddleware,
  setAuthCookie,
  clearAuthCookie,
} from "./auth";
import { insertUserSchema, loginSchema, insertNoteSchema, updateNoteSchema, insertTagSchema, updateTagSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // ============================================
  // AUTH ROUTES
  // ============================================

  // POST /api/register - Create new user account
  app.post("/api/register", async (req, res) => {
    try {
      const parsed = insertUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          message: "Validation failed",
          errors: parsed.error.flatten().fieldErrors,
        });
      }

      const { email, password } = parsed.data;

      // Check if email is already taken
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({ message: "Email is already registered" });
      }

      // Create user with hashed password
      const passwordHash = await hashPassword(password);
      const user = await storage.createUser(email, passwordHash);

      // Generate token and set cookie
      const token = generateToken(user);
      setAuthCookie(res, token);

      res.status(201).json({
        message: "Account created successfully",
        user: toSafeUser(user),
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to create account" });
    }
  });

  // POST /api/login - Authenticate user
  app.post("/api/login", async (req, res) => {
    try {
      const parsed = loginSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          message: "Validation failed",
          errors: parsed.error.flatten().fieldErrors,
        });
      }

      const { email, password } = parsed.data;

      // Find user by email
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Verify password
      const isValid = await verifyPassword(password, user.passwordHash);
      if (!isValid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Generate token and set cookie
      const token = generateToken(user);
      setAuthCookie(res, token);

      res.json({
        message: "Logged in successfully",
        user: toSafeUser(user),
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Failed to log in" });
    }
  });

  // POST /api/logout - Clear auth session
  app.post("/api/logout", (_req, res) => {
    clearAuthCookie(res);
    res.json({ message: "Logged out successfully" });
  });

  // GET /api/me - Get current user
  app.get("/api/me", authMiddleware, async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        clearAuthCookie(res);
        return res.status(401).json({ message: "User not found" });
      }
      res.json({ user: toSafeUser(user) });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // ============================================
  // NOTES ROUTES (All require authentication)
  // ============================================

  // GET /api/notes - Get all notes for current user
  app.get("/api/notes", authMiddleware, async (req, res) => {
    try {
      const notes = await storage.getNotesByUserId(req.user!.id);
      res.json(notes);
    } catch (error) {
      console.error("Get notes error:", error);
      res.status(500).json({ message: "Failed to get notes" });
    }
  });

  // GET /api/notes/:id - Get single note
  app.get("/api/notes/:id", authMiddleware, async (req, res) => {
    try {
      const note = await storage.getNoteById(req.params.id);
      
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }

      // Ensure note belongs to current user
      if (note.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(note);
    } catch (error) {
      console.error("Get note error:", error);
      res.status(500).json({ message: "Failed to get note" });
    }
  });

  // POST /api/notes - Create new note
  app.post("/api/notes", authMiddleware, async (req, res) => {
    try {
      const parsed = insertNoteSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          message: "Validation failed",
          errors: parsed.error.flatten().fieldErrors,
        });
      }

      const note = await storage.createNote(req.user!.id, parsed.data);
      res.status(201).json({ ...note, tags: [] });
    } catch (error) {
      console.error("Create note error:", error);
      res.status(500).json({ message: "Failed to create note" });
    }
  });

  // PUT /api/notes/:id - Update note
  app.put("/api/notes/:id", authMiddleware, async (req, res) => {
    try {
      const parsed = updateNoteSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          message: "Validation failed",
          errors: parsed.error.flatten().fieldErrors,
        });
      }

      // Check note exists and belongs to user
      const existingNote = await storage.getNoteById(req.params.id);
      if (!existingNote) {
        return res.status(404).json({ message: "Note not found" });
      }
      if (existingNote.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      const note = await storage.updateNote(req.params.id, parsed.data);
      const tags = await storage.getTagsForNote(req.params.id);
      res.json({ ...note, tags });
    } catch (error) {
      console.error("Update note error:", error);
      res.status(500).json({ message: "Failed to update note" });
    }
  });

  // DELETE /api/notes/:id - Delete note
  app.delete("/api/notes/:id", authMiddleware, async (req, res) => {
    try {
      // Check note exists and belongs to user
      const existingNote = await storage.getNoteById(req.params.id);
      if (!existingNote) {
        return res.status(404).json({ message: "Note not found" });
      }
      if (existingNote.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      await storage.deleteNote(req.params.id);
      res.json({ message: "Note deleted successfully" });
    } catch (error) {
      console.error("Delete note error:", error);
      res.status(500).json({ message: "Failed to delete note" });
    }
  });

  // PUT /api/notes/:id/tags - Set tags for a note
  app.put("/api/notes/:id/tags", authMiddleware, async (req, res) => {
    try {
      const schema = z.object({
        tagIds: z.array(z.string()),
      });

      const parsed = schema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          message: "Validation failed",
          errors: parsed.error.flatten().fieldErrors,
        });
      }

      // Check note exists and belongs to user
      const existingNote = await storage.getNoteById(req.params.id);
      if (!existingNote) {
        return res.status(404).json({ message: "Note not found" });
      }
      if (existingNote.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Verify all tags belong to user
      for (const tagId of parsed.data.tagIds) {
        const tag = await storage.getTagById(tagId);
        if (!tag || tag.userId !== req.user!.id) {
          return res.status(400).json({ message: "Invalid tag ID" });
        }
      }

      await storage.setNoteTags(req.params.id, parsed.data.tagIds);
      const tags = await storage.getTagsForNote(req.params.id);
      res.json({ ...existingNote, tags });
    } catch (error) {
      console.error("Set note tags error:", error);
      res.status(500).json({ message: "Failed to update note tags" });
    }
  });

  // POST /api/notes/import - Bulk import notes
  app.post("/api/notes/import", authMiddleware, async (req, res) => {
    try {
      const schema = z.object({
        notes: z.array(
          z.object({
            title: z.string().optional().default(""),
            content: z.string().optional().default(""),
          })
        ),
      });

      const parsed = schema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          message: "Invalid import format",
          errors: parsed.error.flatten().fieldErrors,
        });
      }

      const imported = await storage.importNotes(req.user!.id, parsed.data.notes);
      res.json({ message: "Notes imported successfully", imported });
    } catch (error) {
      console.error("Import notes error:", error);
      res.status(500).json({ message: "Failed to import notes" });
    }
  });

  // ============================================
  // TAGS ROUTES (All require authentication)
  // ============================================

  // GET /api/tags - Get all tags for current user
  app.get("/api/tags", authMiddleware, async (req, res) => {
    try {
      const tags = await storage.getTagsByUserId(req.user!.id);
      res.json(tags);
    } catch (error) {
      console.error("Get tags error:", error);
      res.status(500).json({ message: "Failed to get tags" });
    }
  });

  // POST /api/tags - Create new tag
  app.post("/api/tags", authMiddleware, async (req, res) => {
    try {
      const parsed = insertTagSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          message: "Validation failed",
          errors: parsed.error.flatten().fieldErrors,
        });
      }

      const tag = await storage.createTag(req.user!.id, parsed.data);
      res.status(201).json(tag);
    } catch (error) {
      console.error("Create tag error:", error);
      res.status(500).json({ message: "Failed to create tag" });
    }
  });

  // PUT /api/tags/:id - Update tag
  app.put("/api/tags/:id", authMiddleware, async (req, res) => {
    try {
      const parsed = updateTagSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          message: "Validation failed",
          errors: parsed.error.flatten().fieldErrors,
        });
      }

      // Check tag exists and belongs to user
      const existingTag = await storage.getTagById(req.params.id);
      if (!existingTag) {
        return res.status(404).json({ message: "Tag not found" });
      }
      if (existingTag.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      const tag = await storage.updateTag(req.params.id, parsed.data);
      res.json(tag);
    } catch (error) {
      console.error("Update tag error:", error);
      res.status(500).json({ message: "Failed to update tag" });
    }
  });

  // DELETE /api/tags/:id - Delete tag
  app.delete("/api/tags/:id", authMiddleware, async (req, res) => {
    try {
      // Check tag exists and belongs to user
      const existingTag = await storage.getTagById(req.params.id);
      if (!existingTag) {
        return res.status(404).json({ message: "Tag not found" });
      }
      if (existingTag.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      await storage.deleteTag(req.params.id);
      res.json({ message: "Tag deleted successfully" });
    } catch (error) {
      console.error("Delete tag error:", error);
      res.status(500).json({ message: "Failed to delete tag" });
    }
  });

  // ============================================
  // VERSION HISTORY ROUTES (All require authentication)
  // ============================================

  // GET /api/notes/:id/versions - Get version history for a note
  app.get("/api/notes/:id/versions", authMiddleware, async (req, res) => {
    try {
      // Check note exists and belongs to user
      const existingNote = await storage.getNoteById(req.params.id);
      if (!existingNote) {
        return res.status(404).json({ message: "Note not found" });
      }
      if (existingNote.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      const versions = await storage.getNoteVersions(req.params.id);
      res.json(versions);
    } catch (error) {
      console.error("Get note versions error:", error);
      res.status(500).json({ message: "Failed to get note versions" });
    }
  });

  // GET /api/notes/:id/versions/:versionId - Get a specific version
  app.get("/api/notes/:id/versions/:versionId", authMiddleware, async (req, res) => {
    try {
      // Check note exists and belongs to user
      const existingNote = await storage.getNoteById(req.params.id);
      if (!existingNote) {
        return res.status(404).json({ message: "Note not found" });
      }
      if (existingNote.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      const version = await storage.getNoteVersion(req.params.versionId);
      if (!version || version.noteId !== req.params.id) {
        return res.status(404).json({ message: "Version not found" });
      }

      res.json(version);
    } catch (error) {
      console.error("Get note version error:", error);
      res.status(500).json({ message: "Failed to get note version" });
    }
  });

  // POST /api/notes/:id/versions/:versionId/restore - Restore a specific version
  app.post("/api/notes/:id/versions/:versionId/restore", authMiddleware, async (req, res) => {
    try {
      // Check note exists and belongs to user
      const existingNote = await storage.getNoteById(req.params.id);
      if (!existingNote) {
        return res.status(404).json({ message: "Note not found" });
      }
      if (existingNote.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      const restoredNote = await storage.restoreNoteVersion(req.params.id, req.params.versionId);
      if (!restoredNote) {
        return res.status(404).json({ message: "Version not found" });
      }

      const tags = await storage.getTagsForNote(req.params.id);
      res.json({ ...restoredNote, tags });
    } catch (error) {
      console.error("Restore note version error:", error);
      res.status(500).json({ message: "Failed to restore note version" });
    }
  });

  return httpServer;
}

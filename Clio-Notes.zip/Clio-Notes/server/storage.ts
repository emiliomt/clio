import { 
  type User, type Note, type Tag, type NoteWithTags, type NoteVersion,
  type InsertNote, type UpdateNote, type InsertTag, type UpdateTag,
  users, notes, tags, noteTags, noteVersions 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, inArray, max } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(email: string, passwordHash: string): Promise<User>;
  
  getNotesByUserId(userId: string): Promise<NoteWithTags[]>;
  getNoteById(id: string): Promise<Note | undefined>;
  getNoteWithTags(id: string): Promise<NoteWithTags | undefined>;
  createNote(userId: string, data: InsertNote): Promise<Note>;
  updateNote(id: string, data: UpdateNote): Promise<Note | undefined>;
  deleteNote(id: string): Promise<boolean>;
  importNotes(userId: string, notes: { title: string; content: string }[]): Promise<number>;
  
  getTagsByUserId(userId: string): Promise<Tag[]>;
  getTagById(id: string): Promise<Tag | undefined>;
  createTag(userId: string, data: InsertTag): Promise<Tag>;
  updateTag(id: string, data: UpdateTag): Promise<Tag | undefined>;
  deleteTag(id: string): Promise<boolean>;
  
  addTagToNote(noteId: string, tagId: string): Promise<boolean>;
  removeTagFromNote(noteId: string, tagId: string): Promise<boolean>;
  getTagsForNote(noteId: string): Promise<Tag[]>;
  setNoteTags(noteId: string, tagIds: string[]): Promise<boolean>;
  
  getNoteVersions(noteId: string): Promise<NoteVersion[]>;
  createNoteVersion(noteId: string, title: string, content: string): Promise<NoteVersion>;
  getNoteVersion(versionId: string): Promise<NoteVersion | undefined>;
  restoreNoteVersion(noteId: string, versionId: string): Promise<Note | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(email: string, passwordHash: string): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({ email, passwordHash })
      .returning();
    return user;
  }

  async getNotesByUserId(userId: string): Promise<NoteWithTags[]> {
    const userNotes = await db
      .select()
      .from(notes)
      .where(eq(notes.userId, userId))
      .orderBy(desc(notes.updatedAt));
    
    const noteIds = userNotes.map(n => n.id);
    if (noteIds.length === 0) return [];
    
    const noteTagRows = await db
      .select()
      .from(noteTags)
      .innerJoin(tags, eq(noteTags.tagId, tags.id))
      .where(inArray(noteTags.noteId, noteIds));
    
    const tagsByNoteId = new Map<string, Tag[]>();
    for (const row of noteTagRows) {
      const noteId = row.note_tags.noteId;
      if (!tagsByNoteId.has(noteId)) {
        tagsByNoteId.set(noteId, []);
      }
      tagsByNoteId.get(noteId)!.push(row.tags);
    }
    
    return userNotes.map(note => ({
      ...note,
      tags: tagsByNoteId.get(note.id) || [],
    }));
  }

  async getNoteById(id: string): Promise<Note | undefined> {
    const [note] = await db.select().from(notes).where(eq(notes.id, id));
    return note || undefined;
  }

  async getNoteWithTags(id: string): Promise<NoteWithTags | undefined> {
    const note = await this.getNoteById(id);
    if (!note) return undefined;
    
    const noteTags = await this.getTagsForNote(id);
    return { ...note, tags: noteTags };
  }

  async createNote(userId: string, data: InsertNote): Promise<Note> {
    const [note] = await db
      .insert(notes)
      .values({
        userId,
        title: data.title || "",
        content: data.content || "",
      })
      .returning();
    return note;
  }

  async updateNote(id: string, data: UpdateNote): Promise<Note | undefined> {
    const existingNote = await this.getNoteById(id);
    if (!existingNote) return undefined;
    
    const hasChanges = 
      (data.title !== undefined && data.title !== existingNote.title) ||
      (data.content !== undefined && data.content !== existingNote.content);
    
    if (hasChanges && (existingNote.title || existingNote.content)) {
      await this.createNoteVersion(id, existingNote.title, existingNote.content);
    }
    
    const [note] = await db
      .update(notes)
      .set({
        ...(data.title !== undefined && { title: data.title }),
        ...(data.content !== undefined && { content: data.content }),
        updatedAt: new Date(),
      })
      .where(eq(notes.id, id))
      .returning();
    return note || undefined;
  }

  async deleteNote(id: string): Promise<boolean> {
    const result = await db.delete(notes).where(eq(notes.id, id)).returning();
    return result.length > 0;
  }

  async importNotes(userId: string, notesToImport: { title: string; content: string }[]): Promise<number> {
    if (notesToImport.length === 0) return 0;
    
    const values = notesToImport.map((note) => ({
      userId,
      title: note.title || "",
      content: note.content || "",
    }));
    
    const result = await db.insert(notes).values(values).returning();
    return result.length;
  }

  async getTagsByUserId(userId: string): Promise<Tag[]> {
    return db
      .select()
      .from(tags)
      .where(eq(tags.userId, userId))
      .orderBy(tags.name);
  }

  async getTagById(id: string): Promise<Tag | undefined> {
    const [tag] = await db.select().from(tags).where(eq(tags.id, id));
    return tag || undefined;
  }

  async createTag(userId: string, data: InsertTag): Promise<Tag> {
    const [tag] = await db
      .insert(tags)
      .values({
        userId,
        name: data.name,
        color: data.color || "#6366f1",
      })
      .returning();
    return tag;
  }

  async updateTag(id: string, data: UpdateTag): Promise<Tag | undefined> {
    const [tag] = await db
      .update(tags)
      .set({
        ...(data.name !== undefined && { name: data.name }),
        ...(data.color !== undefined && { color: data.color }),
      })
      .where(eq(tags.id, id))
      .returning();
    return tag || undefined;
  }

  async deleteTag(id: string): Promise<boolean> {
    const result = await db.delete(tags).where(eq(tags.id, id)).returning();
    return result.length > 0;
  }

  async addTagToNote(noteId: string, tagId: string): Promise<boolean> {
    try {
      await db.insert(noteTags).values({ noteId, tagId }).onConflictDoNothing();
      return true;
    } catch {
      return false;
    }
  }

  async removeTagFromNote(noteId: string, tagId: string): Promise<boolean> {
    const result = await db
      .delete(noteTags)
      .where(and(eq(noteTags.noteId, noteId), eq(noteTags.tagId, tagId)))
      .returning();
    return result.length > 0;
  }

  async getTagsForNote(noteId: string): Promise<Tag[]> {
    const rows = await db
      .select({ tag: tags })
      .from(noteTags)
      .innerJoin(tags, eq(noteTags.tagId, tags.id))
      .where(eq(noteTags.noteId, noteId));
    
    return rows.map(r => r.tag);
  }

  async setNoteTags(noteId: string, tagIds: string[]): Promise<boolean> {
    await db.delete(noteTags).where(eq(noteTags.noteId, noteId));
    
    if (tagIds.length > 0) {
      await db.insert(noteTags).values(
        tagIds.map(tagId => ({ noteId, tagId }))
      );
    }
    
    return true;
  }

  async getNoteVersions(noteId: string): Promise<NoteVersion[]> {
    return db
      .select()
      .from(noteVersions)
      .where(eq(noteVersions.noteId, noteId))
      .orderBy(desc(noteVersions.version));
  }

  async createNoteVersion(noteId: string, title: string, content: string): Promise<NoteVersion> {
    const [maxVersionResult] = await db
      .select({ maxVersion: max(noteVersions.version) })
      .from(noteVersions)
      .where(eq(noteVersions.noteId, noteId));
    
    const nextVersion = (maxVersionResult?.maxVersion || 0) + 1;
    
    const [version] = await db
      .insert(noteVersions)
      .values({
        noteId,
        title,
        content,
        version: nextVersion,
      })
      .returning();
    
    return version;
  }

  async getNoteVersion(versionId: string): Promise<NoteVersion | undefined> {
    const [version] = await db
      .select()
      .from(noteVersions)
      .where(eq(noteVersions.id, versionId));
    return version || undefined;
  }

  async restoreNoteVersion(noteId: string, versionId: string): Promise<Note | undefined> {
    const version = await this.getNoteVersion(versionId);
    if (!version || version.noteId !== noteId) return undefined;
    
    const currentNote = await this.getNoteById(noteId);
    if (!currentNote) return undefined;
    
    await this.createNoteVersion(noteId, currentNote.title, currentNote.content);
    
    const [updatedNote] = await db
      .update(notes)
      .set({
        title: version.title,
        content: version.content,
        updatedAt: new Date(),
      })
      .where(eq(notes.id, noteId))
      .returning();
    
    return updatedNote || undefined;
  }
}

export const storage = new DatabaseStorage();

import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import type { NoteVersion } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { History, RotateCcw, Loader2, FileText, ChevronRight } from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MarkdownPreview from "@uiw/react-markdown-preview";
import { useTheme } from "@/lib/theme";

interface VersionHistoryProps {
  noteId: string;
  noteTitle: string;
  onVersionRestored: () => void;
}

export function VersionHistory({ noteId, noteTitle, onVersionRestored }: VersionHistoryProps) {
  const [selectedVersion, setSelectedVersion] = useState<NoteVersion | null>(null);
  const [restoreDialogOpen, setRestoreDialogOpen] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);
  const { toast } = useToast();
  const { theme } = useTheme();

  // Fetch version history
  const { data: versions = [], isLoading } = useQuery<NoteVersion[]>({
    queryKey: ["/api/notes", noteId, "versions"],
    enabled: sheetOpen,
  });

  // Restore version mutation
  const restoreMutation = useMutation({
    mutationFn: async (versionId: string) => {
      const response = await apiRequest("POST", `/api/notes/${noteId}/versions/${versionId}/restore`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notes", noteId] });
      queryClient.invalidateQueries({ queryKey: ["/api/notes", noteId, "versions"] });
      setRestoreDialogOpen(false);
      setSelectedVersion(null);
      setSheetOpen(false);
      onVersionRestored();
      toast({
        title: "Version restored",
        description: "The note has been restored to the selected version.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to restore",
        description: "Could not restore the note version. Please try again.",
        variant: "destructive",
      });
    },
  });

  const formatVersionDate = (date: Date | string) => {
    const d = typeof date === "string" ? new Date(date) : date;
    return format(d, "MMM d, yyyy 'at' h:mm a");
  };

  const formatRelativeDate = (date: Date | string) => {
    const d = typeof date === "string" ? new Date(date) : date;
    return formatDistanceToNow(d, { addSuffix: true });
  };

  const getPreview = (content: string) => {
    const plainText = content.replace(/[#*_\[\]`]/g, "").replace(/\n+/g, " ");
    return plainText.slice(0, 100) + (plainText.length > 100 ? "..." : "");
  };

  return (
    <>
      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            data-testid="button-version-history"
          >
            <History className="h-4 w-4 mr-2" />
            History
          </Button>
        </SheetTrigger>
        <SheetContent className="w-full sm:max-w-xl" data-testid="version-history-sheet">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Version History
            </SheetTitle>
            <SheetDescription>
              View and restore previous versions of "{noteTitle || "Untitled"}"
            </SheetDescription>
          </SheetHeader>

          <div className="mt-6 h-[calc(100vh-180px)]">
            {isLoading ? (
              <div className="space-y-3" data-testid="versions-loading">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="p-4 border rounded-lg">
                    <Skeleton className="h-4 w-24 mb-2" />
                    <Skeleton className="h-3 w-full mb-1" />
                    <Skeleton className="h-3 w-3/4" />
                  </div>
                ))}
              </div>
            ) : versions.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center p-6" data-testid="no-versions">
                <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-muted-foreground mb-2">
                  No version history
                </h3>
                <p className="text-sm text-muted-foreground max-w-sm">
                  Version history is created automatically when you make changes to your note. Keep editing to build a history.
                </p>
              </div>
            ) : (
              <ScrollArea className="h-full pr-4" data-testid="versions-list">
                <div className="space-y-2">
                  {versions.map((version, index) => (
                    <button
                      key={version.id}
                      onClick={() => setSelectedVersion(version)}
                      className={`w-full text-left p-4 rounded-lg border transition-colors ${
                        selectedVersion?.id === version.id
                          ? "border-primary bg-primary/5"
                          : "hover-elevate"
                      }`}
                      data-testid={`version-item-${version.id}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="text-xs">
                          v{version.version}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {formatRelativeDate(version.createdAt)}
                        </span>
                      </div>
                      <h4 className="text-sm font-medium truncate mb-1">
                        {version.title || "Untitled"}
                      </h4>
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {getPreview(version.content) || "Empty note"}
                      </p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {formatVersionDate(version.createdAt)}
                      </p>
                    </button>
                  ))}
                </div>
              </ScrollArea>
            )}

            {/* Version Preview Panel */}
            {selectedVersion && (
              <div className="fixed inset-0 bg-background/95 z-50" data-testid="version-preview-panel">
                <div className="h-full flex flex-col">
                  <div className="flex items-center justify-between p-4 border-b">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedVersion(null)}
                        data-testid="button-close-preview"
                      >
                        <ChevronRight className="h-4 w-4 rotate-180 mr-1" />
                        Back
                      </Button>
                      <Badge variant="secondary">v{selectedVersion.version}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {formatVersionDate(selectedVersion.createdAt)}
                      </span>
                    </div>
                    <Button
                      onClick={() => setRestoreDialogOpen(true)}
                      data-testid="button-restore-version"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Restore This Version
                    </Button>
                  </div>
                  <div className="flex-1 overflow-auto p-6">
                    <h1 className="text-2xl font-bold mb-4">{selectedVersion.title || "Untitled"}</h1>
                    <div data-color-mode={theme} className="prose prose-sm dark:prose-invert max-w-none">
                      <MarkdownPreview source={selectedVersion.content || "*No content*"} />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>

      {/* Restore Confirmation Dialog */}
      <AlertDialog open={restoreDialogOpen} onOpenChange={setRestoreDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Restore this version?</AlertDialogTitle>
            <AlertDialogDescription>
              This will replace the current note content with version {selectedVersion?.version}. 
              The current version will be saved to history before restoring.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-restore">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => selectedVersion && restoreMutation.mutate(selectedVersion.id)}
              disabled={restoreMutation.isPending}
              data-testid="button-confirm-restore"
            >
              {restoreMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Restoring...
                </>
              ) : (
                <>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Restore
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

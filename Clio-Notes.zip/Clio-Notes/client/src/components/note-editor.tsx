import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import type { NoteWithTags, Tag } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import MDEditor from "@uiw/react-md-editor";
import MarkdownPreview from "@uiw/react-markdown-preview";
import { VersionHistory } from "./version-history";
import { queryClient } from "@/lib/queryClient";
import { 
  Trash2, 
  Check, 
  Loader2, 
  Download, 
  Upload,
  FileText,
  ChevronDown,
  ChevronUp,
  Link2,
  Tag as TagIcon,
  Eye,
  Edit2,
  Columns
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  ToggleGroup,
  ToggleGroupItem,
} from "@/components/ui/toggle-group";
import { useTheme } from "@/lib/theme";

type EditorMode = "edit" | "preview" | "live";

interface NoteEditorProps {
  note: NoteWithTags | null;
  allNotes: NoteWithTags[];
  tags: Tag[];
  onUpdateNote: (id: string, title: string, content: string) => void;
  onDeleteNote: (id: string) => void;
  onUpdateNoteTags: (noteId: string, tagIds: string[]) => void;
  onNavigateToNote: (noteId: string) => void;
  onCreateNoteWithTitle: (title: string) => void;
  onExport: () => void;
  onImport: (file: File) => void;
  saveStatus: "idle" | "saving" | "saved" | "error";
  isDeleting: boolean;
}

export function NoteEditor({
  note,
  allNotes,
  tags,
  onUpdateNote,
  onDeleteNote,
  onUpdateNoteTags,
  onNavigateToNote,
  onCreateNoteWithTitle,
  onExport,
  onImport,
  saveStatus,
  isDeleting,
}: NoteEditorProps) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [editorMode, setEditorMode] = useState<EditorMode>("edit");
  const [backlinksOpen, setBacklinksOpen] = useState(true);
  const [tagsPopoverOpen, setTagsPopoverOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);
  const { theme } = useTheme();

  // Sync local state with note prop
  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setContent(note.content);
    }
  }, [note?.id]);

  // Cleanup debounce on unmount
  useEffect(() => {
    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, []);

  // Debounced save
  const debouncedSave = useCallback(
    (newTitle: string, newContent: string) => {
      if (!note) return;
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
      debounceRef.current = setTimeout(() => {
        onUpdateNote(note.id, newTitle, newContent);
      }, 300);
    },
    [note, onUpdateNote]
  );

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTitle = e.target.value;
    setTitle(newTitle);
    debouncedSave(newTitle, content);
  };

  const handleContentChange = (value: string | undefined) => {
    const newContent = value || "";
    setContent(newContent);
    debouncedSave(title, newContent);
  };

  // Get current note's tag IDs
  const noteTagIds = useMemo(() => {
    return note?.tags?.map(t => t.id) || [];
  }, [note?.tags]);

  // Toggle tag for note
  const handleToggleTag = (tagId: string) => {
    if (!note) return;
    const newTagIds = noteTagIds.includes(tagId)
      ? noteTagIds.filter(id => id !== tagId)
      : [...noteTagIds, tagId];
    onUpdateNoteTags(note.id, newTagIds);
  };

  // Find backlinks - notes that link to this note
  const backlinks = useMemo(() => {
    if (!note || !note.title.trim()) return [];
    const currentTitle = note.title.toLowerCase();
    
    return allNotes.filter((n) => {
      if (n.id === note.id) return false;
      const linkPattern = new RegExp(`\\[\\[${escapeRegex(currentTitle)}\\]\\]`, "i");
      return linkPattern.test(n.content);
    });
  }, [note, allNotes]);

  // Escape special regex characters
  function escapeRegex(str: string): string {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  // Handle wiki link clicks in preview mode
  const handlePreviewClick = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    const wikiLink = target.closest("[data-wiki-link]");
    if (wikiLink) {
      const linkTitle = wikiLink.textContent;
      if (linkTitle) {
        const linkedNote = allNotes.find(
          (n) => n.title.toLowerCase() === linkTitle.toLowerCase()
        );
        if (linkedNote) {
          onNavigateToNote(linkedNote.id);
        } else {
          onCreateNoteWithTitle(linkTitle);
        }
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImport(file);
      e.target.value = "";
    }
  };

  // Process content to handle wiki links for preview
  const processedContent = useMemo(() => {
    return content.replace(/\[\[([^\]]+)\]\]/g, (_, title) => {
      const linkedNote = allNotes.find(
        (n) => n.title.toLowerCase() === title.toLowerCase()
      );
      const exists = !!linkedNote;
      return `<span data-wiki-link="${title}" class="${exists ? "wiki-link-exists" : "wiki-link-missing"}">${title}</span>`;
    });
  }, [content, allNotes]);

  if (!note) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-background" data-testid="empty-editor-state">
        <FileText className="h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-xl font-medium text-muted-foreground mb-2">
          Select a note
        </h2>
        <p className="text-sm text-muted-foreground text-center max-w-sm">
          Choose a note from the sidebar or create a new one to start writing
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-background" data-testid="note-editor" data-color-mode={theme}>
      {/* Title, Tags & Editor Mode Toggle */}
      <div className="border-b border-border p-4 md:p-6">
        <div className="flex items-start justify-between gap-4 mb-3">
          <Input
            value={title}
            onChange={handleTitleChange}
            placeholder="Untitled"
            className="flex-1 text-2xl font-semibold border-none shadow-none p-0 h-auto bg-transparent focus-visible:ring-0"
            data-testid="input-note-title"
          />
          
          {/* Editor Mode Toggle */}
          <ToggleGroup
            type="single"
            value={editorMode}
            onValueChange={(value) => value && setEditorMode(value as EditorMode)}
            className="border rounded-md"
            data-testid="toggle-editor-mode"
          >
            <ToggleGroupItem 
              value="edit" 
              aria-label="Edit mode" 
              className="px-3"
              data-testid="button-mode-edit"
            >
              <Edit2 className="h-4 w-4" />
            </ToggleGroupItem>
            <ToggleGroupItem 
              value="live" 
              aria-label="Live preview mode"
              className="px-3"
              data-testid="button-mode-live"
            >
              <Columns className="h-4 w-4" />
            </ToggleGroupItem>
            <ToggleGroupItem 
              value="preview" 
              aria-label="Preview mode"
              className="px-3"
              data-testid="button-mode-preview"
            >
              <Eye className="h-4 w-4" />
            </ToggleGroupItem>
          </ToggleGroup>
        </div>
        
        {/* Note Tags */}
        <div className="flex items-center gap-2 flex-wrap">
          {note.tags && note.tags.map((tag) => (
            <Badge
              key={tag.id}
              variant="secondary"
              className="text-xs"
              style={{ backgroundColor: `${tag.color}20`, color: tag.color, borderColor: tag.color }}
              data-testid={`editor-tag-${tag.id}`}
            >
              <span
                className="w-2 h-2 rounded-full mr-1.5"
                style={{ backgroundColor: tag.color }}
              />
              {tag.name}
            </Badge>
          ))}
          
          <Popover open={tagsPopoverOpen} onOpenChange={setTagsPopoverOpen}>
            <PopoverTrigger asChild>
              <Button
                size="sm"
                variant="ghost"
                className="h-6 px-2 text-xs text-muted-foreground"
                data-testid="button-manage-tags"
              >
                <TagIcon className="h-3 w-3 mr-1" />
                {note.tags && note.tags.length > 0 ? "Edit tags" : "Add tags"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-56" align="start">
              <div className="space-y-2">
                <p className="text-sm font-medium">Tags</p>
                {tags.length === 0 ? (
                  <p className="text-xs text-muted-foreground">
                    No tags available. Create one from the sidebar.
                  </p>
                ) : (
                  <div className="space-y-1">
                    {tags.map((tag) => (
                      <label
                        key={tag.id}
                        className="flex items-center gap-2 p-2 rounded-md hover-elevate cursor-pointer"
                        data-testid={`tag-checkbox-${tag.id}`}
                      >
                        <Checkbox
                          checked={noteTagIds.includes(tag.id)}
                          onCheckedChange={() => handleToggleTag(tag.id)}
                        />
                        <span
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: tag.color }}
                        />
                        <span className="text-sm">{tag.name}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto" data-testid="editor-content-area">
        {editorMode === "edit" && (
          <div className="h-full" data-color-mode={theme}>
            <MDEditor
              value={content}
              onChange={handleContentChange}
              preview="edit"
              hideToolbar={false}
              height="100%"
              visibleDragbar={false}
              textareaProps={{
                placeholder: "Start writing your note... Use **bold**, *italic*, # headings, - lists, and [[Note Title]] for wiki links.",
                "data-testid": "textarea-note-content",
              }}
              className="!border-0 !shadow-none"
            />
          </div>
        )}

        {editorMode === "live" && (
          <div className="h-full" data-color-mode={theme}>
            <MDEditor
              value={content}
              onChange={handleContentChange}
              preview="live"
              hideToolbar={false}
              height="100%"
              visibleDragbar={false}
              textareaProps={{
                placeholder: "Start writing your note... Use **bold**, *italic*, # headings, - lists, and [[Note Title]] for wiki links.",
                "data-testid": "textarea-note-content-live",
              }}
              className="!border-0 !shadow-none"
            />
          </div>
        )}

        {editorMode === "preview" && (
          <div 
            className="p-6 md:p-8 max-w-3xl mx-auto prose prose-sm dark:prose-invert" 
            onClick={handlePreviewClick}
            data-testid="markdown-preview"
            data-color-mode={theme}
          >
            {content ? (
              <MarkdownPreview source={processedContent} />
            ) : (
              <p className="text-muted-foreground italic">
                Start writing to see your note preview here...
              </p>
            )}
          </div>
        )}
      </div>

      {/* Markdown Help */}
      {editorMode === "edit" && (
        <div className="border-t border-border px-4 py-2 text-xs text-muted-foreground flex items-center gap-4 flex-wrap" data-testid="markdown-help">
          <span className="font-medium">Markdown:</span>
          <span><code className="bg-muted px-1 rounded">**bold**</code></span>
          <span><code className="bg-muted px-1 rounded">*italic*</code></span>
          <span><code className="bg-muted px-1 rounded"># heading</code></span>
          <span><code className="bg-muted px-1 rounded">- list</code></span>
          <span><code className="bg-muted px-1 rounded">[link](url)</code></span>
          <span><code className="bg-muted px-1 rounded">[[wiki link]]</code></span>
        </div>
      )}

      {/* Backlinks Panel */}
      {backlinks.length > 0 && (
        <div className="border-t border-border" data-testid="backlinks-panel">
          <Collapsible open={backlinksOpen} onOpenChange={setBacklinksOpen}>
            <CollapsibleTrigger 
              className="flex items-center justify-between w-full p-4 hover-elevate"
              data-testid="button-toggle-backlinks"
            >
              <div className="flex items-center gap-2">
                <Link2 className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium" data-testid="text-backlinks-count">
                  Backlinks ({backlinks.length})
                </span>
              </div>
              {backlinksOpen ? (
                <ChevronUp className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              )}
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="px-4 pb-4 flex flex-wrap gap-2">
                {backlinks.map((linkedNote) => (
                  <Badge
                    key={linkedNote.id}
                    variant="secondary"
                    className="cursor-pointer"
                    onClick={() => onNavigateToNote(linkedNote.id)}
                    data-testid={`badge-backlink-${linkedNote.id}`}
                  >
                    {linkedNote.title || "Untitled"}
                  </Badge>
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>
      )}

      {/* Footer Toolbar */}
      <div className="border-t border-border p-4 flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="ghost"
                className="text-destructive"
                disabled={isDeleting}
                data-testid="button-delete-note"
              >
                {isDeleting ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Trash2 className="h-4 w-4 mr-2" />
                )}
                Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete this note?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the
                  note "{title || "Untitled"}".
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => onDeleteNote(note.id)}
                  className="bg-destructive text-destructive-foreground"
                  data-testid="button-confirm-delete"
                >
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {/* Version History */}
          <VersionHistory
            noteId={note.id}
            noteTitle={title}
            onVersionRestored={() => {
              queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
            }}
          />
        </div>

        {/* Save Status */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground" data-testid="save-status-indicator">
          {saveStatus === "saving" && (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              <span data-testid="text-save-status-saving">Saving...</span>
            </>
          )}
          {saveStatus === "saved" && (
            <>
              <Check className="h-4 w-4 text-green-500" />
              <span data-testid="text-save-status-saved">Saved</span>
            </>
          )}
          {saveStatus === "error" && (
            <span className="text-destructive" data-testid="text-save-status-error">Failed to save</span>
          )}
          {saveStatus === "idle" && (
            <span data-testid="text-save-status-idle"></span>
          )}
        </div>

        {/* Export/Import */}
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onExport}
            data-testid="button-export-notes"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleFileSelect}
            className="hidden"
            data-testid="input-import-file"
          />
          <Button
            variant="ghost"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            data-testid="button-import-notes"
          >
            <Upload className="h-4 w-4 mr-2" />
            Import
          </Button>
        </div>
      </div>
    </div>
  );
}

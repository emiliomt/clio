import { useState, useMemo } from "react";
import type { NoteWithTags, Tag } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useTheme } from "@/lib/theme";
import { useAuth } from "@/lib/auth";
import { 
  Plus, 
  Search, 
  BookOpen, 
  Moon, 
  Sun, 
  LogOut,
  FileText,
  Tag as TagIcon,
  X,
  Trash2
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const TAG_COLORS = [
  "#6366f1", "#8b5cf6", "#d946ef", "#ec4899", "#f43f5e",
  "#ef4444", "#f97316", "#eab308", "#84cc16", "#22c55e",
  "#14b8a6", "#06b6d4", "#0ea5e9", "#3b82f6", "#6b7280"
];

interface NotesSidebarProps {
  notes: NoteWithTags[];
  allNotes: NoteWithTags[];
  tags: Tag[];
  selectedNoteId: string | null;
  selectedTagId: string | null;
  onSelectNote: (noteId: string) => void;
  onSelectTag: (tagId: string | null) => void;
  onCreateNote: () => void;
  onCreateTag: (name: string, color: string) => void;
  onDeleteTag: (id: string) => void;
  isLoading: boolean;
  isCreating: boolean;
}

export function NotesSidebar({
  notes,
  allNotes,
  tags,
  selectedNoteId,
  selectedTagId,
  onSelectNote,
  onSelectTag,
  onCreateNote,
  onCreateTag,
  onDeleteTag,
  isLoading,
  isCreating,
}: NotesSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [newTagName, setNewTagName] = useState("");
  const [newTagColor, setNewTagColor] = useState(TAG_COLORS[0]);
  const [tagDialogOpen, setTagDialogOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { logout, user } = useAuth();

  const filteredNotes = useMemo(() => {
    if (!searchQuery.trim()) return notes;
    const query = searchQuery.toLowerCase();
    return notes.filter(
      (note) =>
        note.title.toLowerCase().includes(query) ||
        note.content.toLowerCase().includes(query)
    );
  }, [notes, searchQuery]);

  const formatNoteDate = (date: Date | string) => {
    const d = typeof date === "string" ? new Date(date) : date;
    return formatDistanceToNow(d, { addSuffix: true });
  };

  const getPreview = (content: string) => {
    const plainText = content.replace(/\[\[([^\]]+)\]\]/g, "$1");
    return plainText.slice(0, 60) + (plainText.length > 60 ? "..." : "");
  };

  const handleCreateTag = () => {
    if (newTagName.trim()) {
      onCreateTag(newTagName.trim(), newTagColor);
      setNewTagName("");
      setNewTagColor(TAG_COLORS[0]);
      setTagDialogOpen(false);
    }
  };

  return (
    <aside className="w-72 h-screen flex flex-col bg-sidebar border-r border-sidebar-border" data-testid="notes-sidebar">
      {/* Header */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold text-sidebar-foreground" data-testid="text-app-title">Clio</h1>
          </div>
          <div className="flex items-center gap-1">
            <Button
              size="icon"
              variant="ghost"
              onClick={toggleTheme}
              aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
              data-testid="button-theme-toggle"
            >
              {theme === "dark" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={logout}
              aria-label="Log out"
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
        {user && (
          <p className="text-xs text-muted-foreground mt-2 truncate" data-testid="text-user-email">
            {user.email}
          </p>
        )}
      </div>

      {/* Search */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-background"
            data-testid="input-search-notes"
          />
        </div>
      </div>

      {/* Tags Section */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <TagIcon className="h-4 w-4" />
            <span>Tags</span>
          </div>
          <Dialog open={tagDialogOpen} onOpenChange={setTagDialogOpen}>
            <DialogTrigger asChild>
              <Button size="icon" variant="ghost" className="h-6 w-6" data-testid="button-add-tag">
                <Plus className="h-3 w-3" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Tag</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <Input
                    placeholder="Tag name"
                    value={newTagName}
                    onChange={(e) => setNewTagName(e.target.value)}
                    data-testid="input-tag-name"
                  />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Color</p>
                  <div className="flex flex-wrap gap-2">
                    {TAG_COLORS.map((color) => (
                      <button
                        key={color}
                        onClick={() => setNewTagColor(color)}
                        className={`w-6 h-6 rounded-full transition-all ${
                          newTagColor === color ? "ring-2 ring-offset-2 ring-primary" : ""
                        }`}
                        style={{ backgroundColor: color }}
                        data-testid={`button-color-${color.replace("#", "")}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline" data-testid="button-cancel-tag">Cancel</Button>
                </DialogClose>
                <Button onClick={handleCreateTag} disabled={!newTagName.trim()} data-testid="button-create-tag">
                  Create Tag
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="flex flex-wrap gap-1.5" data-testid="tags-list">
          {selectedTagId && (
            <Button
              size="sm"
              variant="ghost"
              className="h-6 px-2 text-xs"
              onClick={() => onSelectTag(null)}
              data-testid="button-clear-tag-filter"
            >
              <X className="h-3 w-3 mr-1" />
              Clear
            </Button>
          )}
          {tags.map((tag) => (
            <Popover key={tag.id}>
              <PopoverTrigger asChild>
                <Badge
                  variant={selectedTagId === tag.id ? "default" : "secondary"}
                  className="cursor-pointer text-xs"
                  style={selectedTagId === tag.id ? { backgroundColor: tag.color } : undefined}
                  onClick={() => onSelectTag(selectedTagId === tag.id ? null : tag.id)}
                  data-testid={`badge-tag-${tag.id}`}
                >
                  <span
                    className="w-2 h-2 rounded-full mr-1.5"
                    style={{ backgroundColor: selectedTagId === tag.id ? "white" : tag.color }}
                  />
                  {tag.name}
                </Badge>
              </PopoverTrigger>
              <PopoverContent className="w-32 p-2">
                <Button
                  size="sm"
                  variant="destructive"
                  className="w-full"
                  onClick={() => onDeleteTag(tag.id)}
                  data-testid={`button-delete-tag-${tag.id}`}
                >
                  <Trash2 className="h-3 w-3 mr-1" />
                  Delete
                </Button>
              </PopoverContent>
            </Popover>
          ))}
          {tags.length === 0 && (
            <p className="text-xs text-muted-foreground" data-testid="text-no-tags">
              No tags yet
            </p>
          )}
        </div>
      </div>

      {/* New Note Button */}
      <div className="p-4">
        <Button
          className="w-full"
          onClick={onCreateNote}
          disabled={isCreating}
          data-testid="button-new-note"
        >
          <Plus className="h-4 w-4 mr-2" />
          {isCreating ? "Creating..." : "New Note"}
        </Button>
      </div>

      {/* Notes List */}
      <ScrollArea className="flex-1">
        <div className="px-2 pb-4" data-testid="notes-list">
          {isLoading ? (
            <div className="space-y-2" data-testid="notes-loading-skeleton">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="p-3 rounded-lg">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-3 w-full mb-1" />
                  <Skeleton className="h-3 w-1/3" />
                </div>
              ))}
            </div>
          ) : filteredNotes.length === 0 ? (
            <div className="text-center py-8 px-4" data-testid="empty-notes-state">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
              {searchQuery ? (
                <>
                  <p className="text-sm font-medium text-muted-foreground" data-testid="text-no-search-results">
                    No notes found
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Try a different search term
                  </p>
                </>
              ) : selectedTagId ? (
                <>
                  <p className="text-sm font-medium text-muted-foreground" data-testid="text-no-tagged-notes">
                    No notes with this tag
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Add this tag to a note to see it here
                  </p>
                </>
              ) : (
                <>
                  <p className="text-sm font-medium text-muted-foreground" data-testid="text-no-notes">
                    No notes yet
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Create your first note to get started
                  </p>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-1">
              {filteredNotes.map((note) => {
                const isSelected = note.id === selectedNoteId;
                return (
                  <button
                    key={note.id}
                    onClick={() => onSelectNote(note.id)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${
                      isSelected
                        ? "bg-sidebar-accent"
                        : "hover-elevate"
                    }`}
                    data-testid={`button-note-${note.id}`}
                    aria-selected={isSelected}
                  >
                    <h3 className="font-medium text-sm text-sidebar-foreground truncate" data-testid={`text-note-title-${note.id}`}>
                      {note.title || "Untitled"}
                    </h3>
                    {note.content && (
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2" data-testid={`text-note-preview-${note.id}`}>
                        {getPreview(note.content)}
                      </p>
                    )}
                    {note.tags && note.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {note.tags.slice(0, 3).map((tag) => (
                          <span
                            key={tag.id}
                            className="inline-flex items-center px-1.5 py-0.5 rounded-sm text-[10px]"
                            style={{ backgroundColor: `${tag.color}20`, color: tag.color }}
                            data-testid={`note-tag-${note.id}-${tag.id}`}
                          >
                            {tag.name}
                          </span>
                        ))}
                        {note.tags.length > 3 && (
                          <span className="text-[10px] text-muted-foreground">
                            +{note.tags.length - 3}
                          </span>
                        )}
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground mt-2" data-testid={`text-note-date-${note.id}`}>
                      {formatNoteDate(note.updatedAt)}
                    </p>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </ScrollArea>
    </aside>
  );
}

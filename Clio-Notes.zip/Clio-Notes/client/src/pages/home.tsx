import { useState, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import type { NoteWithTags, Tag } from "@shared/schema";
import { NotesSidebar } from "@/components/notes-sidebar";
import { NoteEditor } from "@/components/note-editor";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [selectedTagId, setSelectedTagId] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const { toast } = useToast();

  // Fetch all notes (now includes tags)
  const { data: notes = [], isLoading } = useQuery<NoteWithTags[]>({
    queryKey: ["/api/notes"],
  });

  // Fetch all tags
  const { data: tags = [] } = useQuery<Tag[]>({
    queryKey: ["/api/tags"],
  });

  // Filter notes by selected tag
  const filteredNotes = selectedTagId
    ? notes.filter(note => note.tags?.some(tag => tag.id === selectedTagId))
    : notes;

  // Get selected note
  const selectedNote = notes.find((n) => n.id === selectedNoteId) || null;

  // Create note mutation
  const createNoteMutation = useMutation({
    mutationFn: async (data?: { title?: string }) => {
      const response = await apiRequest("POST", "/api/notes", {
        title: data?.title || "",
        content: "",
      });
      return response.json();
    },
    onSuccess: (newNote: NoteWithTags) => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      setSelectedNoteId(newNote.id);
      toast({
        title: "Note created",
        description: "Your new note is ready.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to create note",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update note mutation
  const updateNoteMutation = useMutation({
    mutationFn: async ({ id, title, content }: { id: string; title: string; content: string }) => {
      const response = await apiRequest("PUT", `/api/notes/${id}`, { title, content });
      return response.json();
    },
    onMutate: async ({ id, title, content }) => {
      setSaveStatus("saving");
      await queryClient.cancelQueries({ queryKey: ["/api/notes"] });
      const previousNotes = queryClient.getQueryData<NoteWithTags[]>(["/api/notes"]);
      queryClient.setQueryData<NoteWithTags[]>(["/api/notes"], (old) =>
        old?.map((n) =>
          n.id === id ? { ...n, title, content, updatedAt: new Date() } : n
        )
      );
      return { previousNotes };
    },
    onSuccess: () => {
      setSaveStatus("saved");
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
    },
    onError: (_, __, context) => {
      setSaveStatus("error");
      if (context?.previousNotes) {
        queryClient.setQueryData(["/api/notes"], context.previousNotes);
      }
      toast({
        title: "Failed to save",
        description: "Your changes could not be saved. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Delete note mutation
  const deleteNoteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/notes/${id}`, undefined);
    },
    onSuccess: (_, deletedId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      if (selectedNoteId === deletedId) {
        setSelectedNoteId(null);
      }
      toast({
        title: "Note deleted",
        description: "The note has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to delete note",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create tag mutation
  const createTagMutation = useMutation({
    mutationFn: async (data: { name: string; color?: string }) => {
      const response = await apiRequest("POST", "/api/tags", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tags"] });
      toast({
        title: "Tag created",
        description: "Your new tag is ready.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to create tag",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  // Delete tag mutation
  const deleteTagMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/tags/${id}`, undefined);
    },
    onSuccess: (_, deletedId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tags"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      if (selectedTagId === deletedId) {
        setSelectedTagId(null);
      }
      toast({
        title: "Tag deleted",
        description: "The tag has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to delete tag",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update note tags mutation
  const updateNoteTagsMutation = useMutation({
    mutationFn: async ({ noteId, tagIds }: { noteId: string; tagIds: string[] }) => {
      const response = await apiRequest("PUT", `/api/notes/${noteId}/tags`, { tagIds });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
    },
    onError: () => {
      toast({
        title: "Failed to update tags",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  // Export notes
  const handleExport = useCallback(() => {
    const exportData = notes.map(({ id, title, content, createdAt, updatedAt, tags }) => ({
      id,
      title,
      content,
      createdAt,
      updatedAt,
      tags: tags?.map(t => t.name) || [],
    }));
    const dataStr = JSON.stringify(exportData, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `clio-notes-${new Date().toISOString().split("T")[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast({
      title: "Notes exported",
      description: `${notes.length} notes have been downloaded.`,
    });
  }, [notes, toast]);

  // Import notes
  const handleImport = useCallback(
    async (file: File) => {
      try {
        const text = await file.text();
        const importedNotes = JSON.parse(text);
        
        if (!Array.isArray(importedNotes)) {
          throw new Error("Invalid format");
        }

        const validNotes = importedNotes.map(note => ({
          title: String(note.title || ""),
          content: String(note.content || ""),
        }));

        const response = await apiRequest("POST", "/api/notes/import", { notes: validNotes });
        const result = await response.json();
        
        queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
        toast({
          title: "Notes imported",
          description: `${result.imported} notes have been added.`,
        });
      } catch (error) {
        toast({
          title: "Import failed",
          description: "Please ensure the file is a valid JSON export.",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  // Navigate to note
  const handleNavigateToNote = useCallback((noteId: string) => {
    setSelectedNoteId(noteId);
  }, []);

  // Create note with title (for wiki links)
  const handleCreateNoteWithTitle = useCallback(
    (title: string) => {
      createNoteMutation.mutate({ title });
    },
    [createNoteMutation]
  );

  return (
    <div className="flex h-screen" data-testid="home-page">
      <NotesSidebar
        notes={filteredNotes}
        allNotes={notes}
        tags={tags}
        selectedNoteId={selectedNoteId}
        selectedTagId={selectedTagId}
        onSelectNote={setSelectedNoteId}
        onSelectTag={setSelectedTagId}
        onCreateNote={() => createNoteMutation.mutate({})}
        onCreateTag={(name, color) => createTagMutation.mutate({ name, color })}
        onDeleteTag={(id) => deleteTagMutation.mutate(id)}
        isLoading={isLoading}
        isCreating={createNoteMutation.isPending}
      />
      <NoteEditor
        note={selectedNote}
        allNotes={notes}
        tags={tags}
        onUpdateNote={(id, title, content) =>
          updateNoteMutation.mutate({ id, title, content })
        }
        onDeleteNote={(id) => deleteNoteMutation.mutate(id)}
        onUpdateNoteTags={(noteId, tagIds) =>
          updateNoteTagsMutation.mutate({ noteId, tagIds })
        }
        onNavigateToNote={handleNavigateToNote}
        onCreateNoteWithTitle={handleCreateNoteWithTitle}
        onExport={handleExport}
        onImport={handleImport}
        saveStatus={saveStatus}
        isDeleting={deleteNoteMutation.isPending}
      />
    </div>
  );
}
